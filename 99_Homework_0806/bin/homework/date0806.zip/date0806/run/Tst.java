package homework.date0806.run;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Tst {
	
	
	public static void main(String[] args) {
		
		
		int date = Integer.parseInt(new SimpleDateFormat("yyyyMMdd").format(new Date()));
		System.out.println(date);
		
		
		
	}

}
